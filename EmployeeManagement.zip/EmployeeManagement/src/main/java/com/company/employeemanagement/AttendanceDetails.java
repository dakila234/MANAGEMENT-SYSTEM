package com.company.employeemanagement;

import java.time.LocalDate;
import java.time.LocalTime;

public class AttendanceDetails {

    private int id;
    private String employeeID;
    private LocalDate work_date;
    private String shift;
    private LocalTime login_time;
    private LocalTime logout_time;
    private String status;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEmployeeID() {
        return employeeID;
    }

    public void setEmployeeID(String employeeID) {
        this.employeeID = employeeID;
    }

    public LocalDate getWork_date() {
        return work_date;
    }

    public void setWork_date(LocalDate work_date) {
        this.work_date = work_date;
    }

    public String getShift() {
        return shift;
    }

    public void setShift(String shift) {
        this.shift = shift;
    }

    public LocalTime getLogin_time() {
        return login_time;
    }

    public void setLogin_time(LocalTime login_time) {
        this.login_time = login_time;
    }

    public LocalTime getLogout_time() {
        return logout_time;
    }

    public void setLogout_time(LocalTime logout_time) {
        this.logout_time = logout_time;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}