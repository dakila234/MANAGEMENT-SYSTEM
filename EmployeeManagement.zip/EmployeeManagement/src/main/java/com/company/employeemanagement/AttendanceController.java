
package com.company.employeemanagement;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

public class AttendanceController {

    AttendanceView av;
    private final DefaultTableModel tableModel;

    public AttendanceController(AttendanceView temp1) {

        av = temp1;

        tableModel = new DefaultTableModel(
                new String[]{
                    "ID", "Employee ID", "Work Date", "Shift",
                    "Login Time", "Logout Time", "Status"
                }, 0) {

            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        av.attendanceTable.setModel(tableModel);

        av.attendanceTable.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION);

        loadEmployeeIDs();
        loadAttendanceTable();

        av.allListeners(new AllActions());

        av.attendanceTable.getSelectionModel()
                .addListSelectionListener(e -> {
                    if (!e.getValueIsAdjusting()) {
                        fillFieldsFromSelectedRow();
                    }
                });
    }

    // LOAD EMPLOYEE IDS
    private void loadEmployeeIDs() {

        ArrayList<String> employeeIDs = new ArrayList<>();

        String sql = "SELECT employeeID FROM employees "
                + "ORDER BY employeeID";

        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                employeeIDs.add(rs.getString("employeeID"));
            }

        } catch (SQLException ex) {
            showError(ex);
            return;
        }

        // Update ComboBox after ResultSet is closed
        av.cmbEmployeeID.removeAllItems();

        for (String employeeID : employeeIDs) {
            av.cmbEmployeeID.addItem(employeeID);
        }
    }

    // LOAD ATTENDANCE TABLE
    private void loadAttendanceTable() {

        tableModel.setRowCount(0);

        String sql = "SELECT id, employeeID, work_date, shift, "
                + "login_time, logout_time, status "
                + "FROM attendance ORDER BY work_date DESC, id DESC";

        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                tableModel.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("employeeID"),
                    rs.getDate("work_date"),
                    rs.getString("shift"),
                    rs.getTime("login_time"),
                    rs.getTime("logout_time"),
                    rs.getString("status")
                });
            }

        } catch (SQLException ex) {
            showError(ex);
        }
    }

    // FILL FIELDS WHEN SELECTING A TABLE ROW
    private void fillFieldsFromSelectedRow() {

        int row = av.attendanceTable.getSelectedRow();

        if (row == -1) {
            return;
        }

        av.cmbEmployeeID.setSelectedItem(
                tableModel.getValueAt(row, 1).toString());

        av.jTextField2.setText(
                tableModel.getValueAt(row, 2).toString());

        av.jTextField3.setText(
                tableModel.getValueAt(row, 3).toString());

        av.jTextField4.setText(
                tableModel.getValueAt(row, 4) == null
                ? "" : tableModel.getValueAt(row, 4).toString());

        av.jTextField5.setText(
                tableModel.getValueAt(row, 5) == null
                ? "" : tableModel.getValueAt(row, 5).toString());

        av.jTextField6.setText(
                tableModel.getValueAt(row, 6).toString());
    }

    // GET SELECTED ATTENDANCE ID
    private int getSelectedAttendanceID() {

        int row = av.attendanceTable.getSelectedRow();

        if (row == -1) {
            JOptionPane.showMessageDialog(
                    av, "Select an attendance row first.");
            return -1;
        }

        return Integer.parseInt(
                tableModel.getValueAt(row, 0).toString());
    }

    // VALIDATE FIELDS
    private boolean validateFields() {

        if (av.cmbEmployeeID.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(av, "Select an Employee ID.");
            return false;
        }

        if (av.jTextField2.getText().trim().isEmpty()
                || av.jTextField3.getText().trim().isEmpty()
                || av.jTextField6.getText().trim().isEmpty()) {

            JOptionPane.showMessageDialog(
                    av, "Please fill in Work Date, Shift, and Status.");

            return false;
        }

        try {

            LocalDate.parse(av.jTextField2.getText().trim());

            if (!av.jTextField4.getText().trim().isEmpty()) {
                LocalTime.parse(av.jTextField4.getText().trim());
            }

            if (!av.jTextField5.getText().trim().isEmpty()) {
                LocalTime.parse(av.jTextField5.getText().trim());
            }

        } catch (DateTimeParseException ex) {

            JOptionPane.showMessageDialog(
                    av,
                    "Invalid date or time format.\n"
                    + "Date: YYYY-MM-DD\n"
                    + "Time: HH:MM:SS (24-hour format)"
            );

            return false;
        }

        return true;
    }

    // GET FORM DATA
    private AttendanceDetails getFormDetails() {

        AttendanceDetails attendance = new AttendanceDetails();

        attendance.setEmployeeID(
                av.cmbEmployeeID.getSelectedItem().toString());

        attendance.setWork_date(
                LocalDate.parse(av.jTextField2.getText().trim()));

        attendance.setShift(
                av.jTextField3.getText().trim());

        String login = av.jTextField4.getText().trim();

        attendance.setLogin_time(
                login.isEmpty() ? null : LocalTime.parse(login));

        String logout = av.jTextField5.getText().trim();

        attendance.setLogout_time(
                logout.isEmpty() ? null : LocalTime.parse(logout));

        attendance.setStatus(
                av.jTextField6.getText().trim());

        return attendance;
    }

    // SAVE ATTENDANCE
    private void saveAttendance() {

        if (!validateFields()) {
            return;
        }

        AttendanceDetails attendance = getFormDetails();

        String sql = "INSERT INTO attendance "
                + "(employeeID, work_date, shift, login_time, logout_time, status) "
                + "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            setAttendanceParameters(ps, attendance);

            ps.executeUpdate();

            JOptionPane.showMessageDialog(av, "Attendance added!");

            loadAttendanceTable();
            clearFields();

        } catch (SQLException ex) {
            showError(ex);
        }
    }

    // READ ATTENDANCE
    private void readAttendance() {

        loadAttendanceTable();

        if (tableModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(
                    av, "No attendance records found.");
        }
    }

    // REFRESH ATTENDANCE
    private void refreshAttendance() {

        loadEmployeeIDs();
        loadAttendanceTable();
        clearFields();

        JOptionPane.showMessageDialog(
                av, "Employee IDs and attendance table refreshed!");
    }

    // UPDATE ATTENDANCE
    private void updateAttendance() {

        int id = getSelectedAttendanceID();

        if (id == -1 || !validateFields()) {
            return;
        }

        int choice = JOptionPane.showConfirmDialog(
                av,
                "Update the selected attendance record?",
                "Confirm Update",
                JOptionPane.YES_NO_OPTION);

        if (choice != JOptionPane.YES_OPTION) {
            return;
        }

        AttendanceDetails attendance = getFormDetails();

        String sql = "UPDATE attendance SET employeeID = ?, work_date = ?, "
                + "shift = ?, login_time = ?, logout_time = ?, status = ? "
                + "WHERE id = ?";

        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            setAttendanceParameters(ps, attendance);
            ps.setInt(7, id);

            if (ps.executeUpdate() > 0) {

                JOptionPane.showMessageDialog(av, "Attendance updated!");

                loadAttendanceTable();
                clearFields();

            } else {
                JOptionPane.showMessageDialog(
                        av, "No record was updated.");
            }

        } catch (SQLException ex) {
            showError(ex);
        }
    }

    // DELETE ATTENDANCE
    private void deleteAttendance() {

        int id = getSelectedAttendanceID();

        if (id == -1) {
            return;
        }

        int choice = JOptionPane.showConfirmDialog(
                av,
                "Delete the selected attendance record?",
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE);

        if (choice != JOptionPane.YES_OPTION) {
            return;
        }

        String sql = "DELETE FROM attendance WHERE id = ?";

        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);

            if (ps.executeUpdate() > 0) {

                JOptionPane.showMessageDialog(av, "Attendance deleted!");

                loadAttendanceTable();
                clearFields();

            } else {
                JOptionPane.showMessageDialog(
                        av, "No record was deleted.");
            }

        } catch (SQLException ex) {
            showError(ex);
        }
    }

    // SET SQL PARAMETERS
    private void setAttendanceParameters(
            PreparedStatement ps,
            AttendanceDetails attendance) throws SQLException {

        ps.setString(1, attendance.getEmployeeID());

        ps.setDate(2, java.sql.Date.valueOf(
                attendance.getWork_date()));

        ps.setString(3, attendance.getShift());

        if (attendance.getLogin_time() == null) {
            ps.setNull(4, java.sql.Types.TIME);
        } else {
            ps.setTime(4, java.sql.Time.valueOf(
                    attendance.getLogin_time()));
        }

        if (attendance.getLogout_time() == null) {
            ps.setNull(5, java.sql.Types.TIME);
        } else {
            ps.setTime(5, java.sql.Time.valueOf(
                    attendance.getLogout_time()));
        }

        ps.setString(6, attendance.getStatus());
    }

    // CLEAR FIELDS
    private void clearFields() {

        av.jTextField2.setText("");
        av.jTextField3.setText("");
        av.jTextField4.setText("");
        av.jTextField5.setText("");
        av.jTextField6.setText("");

        av.attendanceTable.clearSelection();
    }

    // SHOW DATABASE ERRORS
    private void showError(SQLException ex) {

        JOptionPane.showMessageDialog(
                av,
                "Database error: " + ex.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE);
    }

    // BUTTON ACTIONS
    class AllActions implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            Object source = e.getSource();

            // SAVE
            if (source == av.saveBTN4) {

                saveAttendance();

            } // READ
            else if (source == av.readBTN4) {

                readAttendance();

            } // UPDATE
            else if (source == av.updateBTN4) {

                updateAttendance();

            } // DELETE
            else if (source == av.deleteBTN4) {

                deleteAttendance();

            } // REFRESH
            else if (source == av.refreshBTN4) {

                refreshAttendance();
            }
        }
    }
}
