    
package com.company.employeemanagement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class DB {

    private static Connection conn;

    private static Connection createConnection() {
        try {
            String url = "jdbc:mysql://localhost/employee_management";
            Class.forName("com.mysql.jdbc.Driver"); //the driver of the database
            conn = DriverManager.getConnection(url, "root", "amethsy123");
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(DB.class.getName()).log(Level.SEVERE, null, ex);
            System.err.print(ex);
            JOptionPane.showMessageDialog(null, "Database Error!", "Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }
        return conn;
    }

    public static Connection getConnection() {
        try {
            if (conn == null || conn.isClosed()) {
                conn = createConnection();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Database Error!", "Error", JOptionPane.ERROR_MESSAGE);
            Logger.getLogger(DB.class.getName()).log(Level.SEVERE, null, ex);
        }
        return conn;
    }

    
}