package com.company.employeemanagement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.math.BigDecimal;
import java.time.LocalDate;
import javax.swing.JOptionPane;

public class DAO2 {

    // SAVE EMPLOYMENT DETAILS
    public static boolean save(EmploymentDetails em) {

        String sql = "INSERT INTO employment_details "
                + "(employeeID, job_position, salary, employment_status, hire_date) "
                + "VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DB.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, em.getEmployeeID());
            stmt.setString(2, em.getJob_position());
            stmt.setBigDecimal(3, em.getSalary());
            stmt.setString(4, em.getEmployment_status());

            if (em.getHire_date() == null) {
                stmt.setDate(5, null);
            } else {
                stmt.setDate(5,
                        java.sql.Date.valueOf(em.getHire_date()));
            }

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(
                    null, "Employment details added!"
            );

            return true;

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                    null,
                    "Could not add employment details:\n" + ex.getMessage()
            );

            return false;
        }
    }

    // READ EMPLOYMENT DETAILS
    public static EmploymentDetails read(String employeeID) {

        String sql = "SELECT * FROM employment_details "
                + "WHERE employeeID = ?";

        try (Connection conn = DB.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, employeeID);

            try (ResultSet rs = stmt.executeQuery()) {

                if (rs.next()) {

                    EmploymentDetails em = new EmploymentDetails();

                    em.setId(rs.getInt("id"));
                    em.setEmployeeID(rs.getString("employeeID"));
                    em.setJob_position(rs.getString("job_position"));
                    em.setSalary(rs.getBigDecimal("salary"));
                    em.setEmployment_status(
                            rs.getString("employment_status")
                    );

                    java.sql.Date date = rs.getDate("hire_date");

                    if (date != null) {
                        em.setHire_date(date.toLocalDate());
                    }

                    return em;
                }
            }

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                    null,
                    "Could not read employment details:\n" + ex.getMessage()
            );
        }

        return null;
    }

    // UPDATE EMPLOYMENT DETAILS
    public static boolean update(EmploymentDetails em) {

        String sql = "UPDATE employment_details SET "
                + "job_position = ?, salary = ?, "
                + "employment_status = ?, hire_date = ? "
                + "WHERE employeeID = ?";

        try (Connection conn = DB.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, em.getJob_position());
            stmt.setBigDecimal(2, em.getSalary());
            stmt.setString(3, em.getEmployment_status());

            if (em.getHire_date() == null) {
                stmt.setDate(4, null);
            } else {
                stmt.setDate(4,
                        java.sql.Date.valueOf(em.getHire_date()));
            }

            stmt.setString(5, em.getEmployeeID());

            int rows = stmt.executeUpdate();

            if (rows > 0) {

                JOptionPane.showMessageDialog(
                        null, "Employment details updated!"
                );

                return true;

            } else {

                JOptionPane.showMessageDialog(
                        null,
                        "No employment details found for this Employee ID."
                );
            }

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                    null,
                    "Could not update employment details:\n" + ex.getMessage()
            );
        }

        return false;
    }

    // DELETE EMPLOYMENT DETAILS
    public static boolean delete(String employeeID) {

        String sql = "DELETE FROM employment_details "
                + "WHERE employeeID = ?";

        try (Connection conn = DB.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, employeeID);

            int rows = stmt.executeUpdate();

            if (rows > 0) {

                JOptionPane.showMessageDialog(
                        null, "Employment details deleted!"
                );

                return true;

            } else {

                JOptionPane.showMessageDialog(
                        null,
                        "No employment details found for this Employee ID."
                );
            }

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                    null,
                    "Could not delete employment details:\n" + ex.getMessage()
            );
        }

        return false;
    }
}