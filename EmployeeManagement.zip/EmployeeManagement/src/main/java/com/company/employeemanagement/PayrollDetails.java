package com.company.employeemanagement;

import java.math.BigDecimal;
import java.time.LocalDate;

public class PayrollDetails {

    private int id;
    private String employeeID;
    private LocalDate pay_date;
    private String pay_period;
    private BigDecimal daily_rate;
    private int days_worked;
    private BigDecimal basic_salary;
    private BigDecimal overtime_pay;
    private BigDecimal gross_salary;
    private BigDecimal deductions;
    private BigDecimal net_salary;
    private String payment_status;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEmployeeID() {
        return employeeID;
    }

    public void setEmployeeID(String employeeID) {
        this.employeeID = employeeID;
    }

    public LocalDate getPay_date() {
        return pay_date;
    }

    public void setPay_date(LocalDate pay_date) {
        this.pay_date = pay_date;
    }

    public String getPay_period() {
        return pay_period;
    }

    public void setPay_period(String pay_period) {
        this.pay_period = pay_period;
    }

    public BigDecimal getDaily_rate() {
        return daily_rate;
    }

    public void setDaily_rate(BigDecimal daily_rate) {
        this.daily_rate = daily_rate;
    }

    public int getDays_worked() {
        return days_worked;
    }

    public void setDays_worked(int days_worked) {
        this.days_worked = days_worked;
    }

    public BigDecimal getBasic_salary() {
        return basic_salary;
    }

    public void setBasic_salary(BigDecimal basic_salary) {
        this.basic_salary = basic_salary;
    }

    public BigDecimal getOvertime_pay() {
        return overtime_pay;
    }

    public void setOvertime_pay(BigDecimal overtime_pay) {
        this.overtime_pay = overtime_pay;
    }

    public BigDecimal getGross_salary() {
        return gross_salary;
    }

    public void setGross_salary(BigDecimal gross_salary) {
        this.gross_salary = gross_salary;
    }

    public BigDecimal getDeductions() {
        return deductions;
    }

    public void setDeductions(BigDecimal deductions) {
        this.deductions = deductions;
    }

    public BigDecimal getNet_salary() {
        return net_salary;
    }

    public void setNet_salary(BigDecimal net_salary) {
        this.net_salary = net_salary;
    }

    public String getPayment_status() {
        return payment_status;
    }

    public void setPayment_status(String payment_status) {
        this.payment_status = payment_status;
    }
}