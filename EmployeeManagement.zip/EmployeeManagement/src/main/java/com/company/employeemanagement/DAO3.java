package com.company.employeemanagement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class DAO3 {

    // SAVE PAYROLL
    public static boolean save(PayrollDetails p) {

        String sql = "INSERT INTO payroll "
                + "(employeeID, pay_date, pay_period, daily_rate, "
                + "days_worked, basic_salary, overtime_pay, "
                + "gross_salary, deductions, net_salary, payment_status) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, p.getEmployeeID());
            ps.setDate(2, java.sql.Date.valueOf(p.getPay_date()));
            ps.setString(3, p.getPay_period());
            ps.setBigDecimal(4, p.getDaily_rate());
            ps.setInt(5, p.getDays_worked());
            ps.setBigDecimal(6, p.getBasic_salary());
            ps.setBigDecimal(7, p.getOvertime_pay());
            ps.setBigDecimal(8, p.getGross_salary());
            ps.setBigDecimal(9, p.getDeductions());
            ps.setBigDecimal(10, p.getNet_salary());
            ps.setString(11, p.getPayment_status());

            ps.executeUpdate();

            JOptionPane.showMessageDialog(null, "Payroll added!");

            return true;

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                    null, "Could not save payroll:\n" + ex.getMessage()
            );

            return false;
        }
    }

    // LOAD PAYROLL TABLE
    public static void loadTable(DefaultTableModel model) {

        model.setRowCount(0);

        String sql = "SELECT * FROM payroll ORDER BY id";

        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                model.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("employeeID"),
                    rs.getDate("pay_date"),
                    rs.getString("pay_period"),
                    rs.getBigDecimal("daily_rate"),
                    rs.getInt("days_worked"),
                    rs.getBigDecimal("basic_salary"),
                    rs.getBigDecimal("overtime_pay"),
                    rs.getBigDecimal("gross_salary"),
                    rs.getBigDecimal("deductions"),
                    rs.getBigDecimal("net_salary"),
                    rs.getString("payment_status")
                });
            }

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                    null, "Could not load payroll:\n" + ex.getMessage()
            );
        }
    }

    // UPDATE PAYROLL
    public static boolean update(int id, PayrollDetails p) {

        String sql = "UPDATE payroll SET "
                + "employeeID=?, pay_date=?, pay_period=?, "
                + "daily_rate=?, days_worked=?, basic_salary=?, "
                + "overtime_pay=?, gross_salary=?, deductions=?, "
                + "net_salary=?, payment_status=? "
                + "WHERE id=?";

        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, p.getEmployeeID());
            ps.setDate(2, java.sql.Date.valueOf(p.getPay_date()));
            ps.setString(3, p.getPay_period());
            ps.setBigDecimal(4, p.getDaily_rate());
            ps.setInt(5, p.getDays_worked());
            ps.setBigDecimal(6, p.getBasic_salary());
            ps.setBigDecimal(7, p.getOvertime_pay());
            ps.setBigDecimal(8, p.getGross_salary());
            ps.setBigDecimal(9, p.getDeductions());
            ps.setBigDecimal(10, p.getNet_salary());
            ps.setString(11, p.getPayment_status());
            ps.setInt(12, id);

            int rows = ps.executeUpdate();

            if (rows > 0) {

                JOptionPane.showMessageDialog(null, "Payroll updated!");

                return true;
            }

            JOptionPane.showMessageDialog(null, "Payroll record not found.");

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                    null, "Could not update payroll:\n" + ex.getMessage()
            );
        }

        return false;
    }

    // DELETE PAYROLL
    public static boolean delete(int id) {

        String sql = "DELETE FROM payroll WHERE id=?";

        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);

            int rows = ps.executeUpdate();

            if (rows > 0) {

                JOptionPane.showMessageDialog(null, "Payroll deleted!");

                return true;
            }

            JOptionPane.showMessageDialog(null, "Payroll record not found.");

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                    null, "Could not delete payroll:\n" + ex.getMessage()
            );
        }

        return false;
    }
}