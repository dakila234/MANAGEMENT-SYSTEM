

package com.company.employeemanagement;
import java.awt.FlowLayout;
import java.awt.BorderLayout;
import java.awt.Container;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.Month;
import java.util.Locale;
import javax.swing.JComboBox;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
public class DashboardView extends javax.swing.JFrame {
    
private JLabel totalEmployeesLabel;
private JLabel presentLabel;
private JLabel absentLabel;
private JComboBox<String> monthCombo;
private JComboBox<Integer> yearCombo;

private JTable attendanceSummaryTable;
private DefaultTableModel attendanceTableModel;
  
    public DashboardView() {
    initComponents();

    // Create dashboard panel
    JPanel dashboardPanel = createDashboardPanel();

    // Replace the existing empty Dashboard tab
    int dashboardIndex = dashboardTabs.indexOfTab("DASHBOARD");
    dashboardTabs.setComponentAt(dashboardIndex, dashboardPanel);

    setTitle("Employee Management System");
    setSize(1100, 700);
    setLocationRelativeTo(null);

    refreshDashboard();
}

public DashboardView(
        EmployeeView employee,
        EmploymentDetailsView employment,
        PayrollView payroll,
        AttendanceView attendance) {

    initComponents();

    // Create dashboard panel
    JPanel dashboardPanel = createDashboardPanel();

    // Replace the existing empty Dashboard tab
    int dashboardIndex = dashboardTabs.indexOfTab("DASHBOARD");
    dashboardTabs.setComponentAt(dashboardIndex, dashboardPanel);

    // Set layouts
    jPanel1.setLayout(new BorderLayout());
    jPanel2.setLayout(new BorderLayout());
    jPanel3.setLayout(new BorderLayout());
    jPanel4.setLayout(new BorderLayout());

    // Connect existing forms
    connectForm(employee, jPanel1);
    connectForm(employment, jPanel2);
    connectForm(payroll, jPanel3);
    connectForm(attendance, jPanel4);

    // Refresh dashboard when selected
    dashboardTabs.addChangeListener(e -> {
        if (dashboardTabs.getSelectedComponent() == dashboardPanel) {
            refreshDashboard();
        }
    });

    setTitle("Employee Management System");
    setSize(1100, 700);
    setLocationRelativeTo(null);

    refreshDashboard();
}
 
private JPanel createDashboardPanel() {

    JPanel mainPanel = new JPanel(new BorderLayout(15, 15));
    mainPanel.setBackground(new Color(245, 247, 250));

    mainPanel.setBorder(
        javax.swing.BorderFactory.createEmptyBorder(25, 25, 25, 25)
    );

    // DASHBOARD TITLE
    JLabel title = new JLabel("Employee Management Dashboard");
    title.setFont(new Font("Arial", Font.BOLD, 26));

    // DASHBOARD CARDS
    JPanel cards = new JPanel(new GridLayout(1, 3, 15, 15));
    cards.setOpaque(false);

    totalEmployeesLabel = new JLabel("0");
    presentLabel = new JLabel("0");
    absentLabel = new JLabel("0");

    cards.add(createCard(
        "TOTAL EMPLOYEES",
        totalEmployeesLabel,
        new Color(52, 152, 219)
    ));

    cards.add(createCard(
        "PRESENT (SELECTED MONTH)",
        presentLabel,
        new Color(46, 204, 113)
    ));

    cards.add(createCard(
        "ABSENT (SELECTED MONTH)",
        absentLabel,
        new Color(231, 76, 60)
    ));

    // TOP SECTION
    JPanel top = new JPanel(new BorderLayout(10, 25));
    top.setOpaque(false);

    top.add(title, BorderLayout.NORTH);
    top.add(cards, BorderLayout.CENTER);

    mainPanel.add(top, BorderLayout.NORTH);

    // MONTH AND YEAR SELECTION
    JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
    filterPanel.setOpaque(false);

    JLabel monthLabel = new JLabel("Select Month:");
    monthLabel.setFont(new Font("Arial", Font.BOLD, 14));

    monthCombo = new JComboBox<>();

    for (Month month : Month.values()) {
        monthCombo.addItem(
            month.toString().substring(0, 1)
                + month.toString().substring(1).toLowerCase()
        );
    }

    JLabel yearLabel = new JLabel("Select Year:");
    yearLabel.setFont(new Font("Arial", Font.BOLD, 14));

    yearCombo = new JComboBox<>();

    int currentYear = LocalDate.now().getYear();

    for (int year = currentYear - 5; year <= currentYear + 1; year++) {
        yearCombo.addItem(year);
    }

    monthCombo.setSelectedIndex(LocalDate.now().getMonthValue() - 1);
    yearCombo.setSelectedItem(currentYear);

    filterPanel.add(monthLabel);
    filterPanel.add(monthCombo);
    filterPanel.add(yearLabel);
    filterPanel.add(yearCombo);

    // ATTENDANCE TABLE
    attendanceTableModel = new DefaultTableModel(
        new String[]{
            "Employee ID",
            "First Name",
            "Last Name",
            "Present",
            "Absent"
        }, 0
    ) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    attendanceSummaryTable = new JTable(attendanceTableModel);

    attendanceSummaryTable.setRowHeight(25);
    attendanceSummaryTable.getTableHeader().setFont(
        new Font("Arial", Font.BOLD, 13)
    );

    JScrollPane tableScrollPane =
        new JScrollPane(attendanceSummaryTable);

    JPanel attendancePanel = new JPanel(new BorderLayout(10, 10));
    attendancePanel.setOpaque(false);

    JLabel attendanceTitle = new JLabel("Monthly Employee Attendance");
    attendanceTitle.setFont(new Font("Arial", Font.BOLD, 18));

    attendancePanel.add(attendanceTitle, BorderLayout.NORTH);
    attendancePanel.add(filterPanel, BorderLayout.CENTER);

    JPanel tableContainer = new JPanel(new BorderLayout());
    tableContainer.add(tableScrollPane, BorderLayout.CENTER);

    JPanel centerPanel = new JPanel(new BorderLayout(10, 10));
    centerPanel.setOpaque(false);

    centerPanel.add(attendancePanel, BorderLayout.NORTH);
    centerPanel.add(tableContainer, BorderLayout.CENTER);

    mainPanel.add(centerPanel, BorderLayout.CENTER);

    // AUTOMATICALLY REFRESH WHEN MONTH OR YEAR CHANGES
    monthCombo.addActionListener(e -> refreshDashboard());
    yearCombo.addActionListener(e -> refreshDashboard());

    return mainPanel;
}

private JPanel createCard(
        String title, JLabel value, Color color) {

    JPanel card = new JPanel(new BorderLayout(10, 15));
    card.setBackground(color);

    card.setBorder(
        javax.swing.BorderFactory.createEmptyBorder(20, 20, 20, 20)
    );

    JLabel heading = new JLabel(title);
    heading.setForeground(Color.WHITE);
    heading.setFont(new Font("Arial", Font.PLAIN, 15));

    value.setForeground(Color.WHITE);
    value.setFont(new Font("Arial", Font.BOLD, 36));

    card.add(heading, BorderLayout.NORTH);
    card.add(value, BorderLayout.CENTER);

    return card;
}

private void refreshDashboard() {

    if (monthCombo == null || yearCombo == null) {
        return;
    }

    int selectedMonth = monthCombo.getSelectedIndex() + 1;

    int selectedYear = (Integer) yearCombo.getSelectedItem();

    YearMonth selectedPeriod =
        YearMonth.of(selectedYear, selectedMonth);

    LocalDate startDate = selectedPeriod.atDay(1);
    LocalDate endDate = selectedPeriod.plusMonths(1).atDay(1);

    String sql =
        "SELECT e.employeeID, e.first_name, e.last_name, " +
        "SUM(CASE WHEN LOWER(a.status) = 'present' THEN 1 ELSE 0 END) AS present_count, " +
        "SUM(CASE WHEN LOWER(a.status) = 'absent' THEN 1 ELSE 0 END) AS absent_count " +
        "FROM employees e " +
        "LEFT JOIN attendance a " +
        "ON e.employeeID = a.employeeID " +
        "AND a.work_date >= ? AND a.work_date < ? " +
        "GROUP BY e.employeeID, e.first_name, e.last_name " +
        "ORDER BY e.employeeID";

    attendanceTableModel.setRowCount(0);

    int totalEmployees = 0;
    int totalPresent = 0;
    int totalAbsent = 0;

    try (Connection con = DB.getConnection();
         PreparedStatement ps = con.prepareStatement(sql)) {

        ps.setDate(1, java.sql.Date.valueOf(startDate));
        ps.setDate(2, java.sql.Date.valueOf(endDate));

        try (ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                String employeeID = rs.getString("employeeID");
                String firstName = rs.getString("first_name");
                String lastName = rs.getString("last_name");

                int present = rs.getInt("present_count");
                int absent = rs.getInt("absent_count");

                attendanceTableModel.addRow(new Object[]{
                    employeeID,
                    firstName,
                    lastName,
                    present,
                    absent
                });

                totalEmployees++;
                totalPresent += present;
                totalAbsent += absent;
            }
        }

        // UPDATE DASHBOARD CARDS
        totalEmployeesLabel.setText(
            String.valueOf(totalEmployees)
        );

        presentLabel.setText(
            String.valueOf(totalPresent)
        );

        absentLabel.setText(
            String.valueOf(totalAbsent)
        );

    } catch (SQLException ex) {

        JOptionPane.showMessageDialog(
            this,
            "Dashboard error: " + ex.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE
        );
    }
}
   


private void connectForm(JFrame form, JPanel panel) {

    Container content = form.getContentPane();

    form.setVisible(false);
    form.setContentPane(new JPanel());

    panel.removeAll();
    panel.setLayout(new BorderLayout());

    javax.swing.JScrollPane scrollPane =
            new javax.swing.JScrollPane(content);

    scrollPane.setVerticalScrollBarPolicy(
            javax.swing.JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED
    );

    scrollPane.setHorizontalScrollBarPolicy(
            javax.swing.JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED
    );

    panel.add(scrollPane, BorderLayout.CENTER);

    panel.revalidate();
    panel.repaint();

}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        dashboardTabs = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        dashboardTabs.setBackground(new java.awt.Color(102, 204, 255));

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1264, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 902, Short.MAX_VALUE)
        );

        dashboardTabs.addTab("EMPLOYEE DETAILS", jPanel1);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1264, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 902, Short.MAX_VALUE)
        );

        dashboardTabs.addTab("EMPLOYMENT DETAILS", jPanel2);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1264, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 902, Short.MAX_VALUE)
        );

        dashboardTabs.addTab("ATTENDANCE", jPanel4);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1264, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 902, Short.MAX_VALUE)
        );

        dashboardTabs.addTab("PAYROLL", jPanel3);

        jTabbedPane1.setBackground(new java.awt.Color(255, 153, 153));
        jTabbedPane1.setForeground(new java.awt.Color(0, 51, 204));
        dashboardTabs.addTab("DASHBOARD", jTabbedPane1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(dashboardTabs)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(dashboardTabs)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JTabbedPane dashboardTabs;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JTabbedPane jTabbedPane1;
    // End of variables declaration//GEN-END:variables
}
