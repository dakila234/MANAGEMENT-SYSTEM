
package com.company.employeemanagement;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

public class PayrollController {

    PayrollView pv;

    private final DefaultTableModel tableModel;

    public PayrollController(PayrollView temp1) {

        pv = temp1;

        tableModel = new DefaultTableModel(
                new String[]{
                    "ID",
                    "Employee ID",
                    "Pay Date",
                    "Pay Period",
                    "Daily Rate",
                    "Days Worked",
                    "Basic Salary",
                    "Overtime Pay",
                    "Gross Salary",
                    "Deductions",
                    "Net Salary",
                    "Payment Status"
                }, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        pv.payrollTable.setModel(tableModel);

        pv.payrollTable.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );

        pv.allListeners(new AllActions());

        loadEmployeeIDs();
        loadPayrollTable();

        pv.payrollTable.getSelectionModel().addListSelectionListener(e -> {

            if (!e.getValueIsAdjusting()) {
                fillFieldsFromSelectedRow();
            }
        });
    }

    // LOAD EMPLOYEE IDS
    private void loadEmployeeIDs() {

        ArrayList<String> employeeIDs = new ArrayList<>();

        String sql = "SELECT employeeID FROM employees "
                + "ORDER BY employeeID";

        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                employeeIDs.add(rs.getString("employeeID"));
            }

        } catch (SQLException ex) {
            showError(ex);
            return;
        }

        // Update ComboBox after ResultSet is closed
        pv.cmbEmployeeIDd.removeAllItems();

        for (String employeeID : employeeIDs) {
            pv.cmbEmployeeIDd.addItem(employeeID);
        }
    }

    // LOAD PAYROLL TABLE
    private void loadPayrollTable() {

        DAO3.loadTable(tableModel);
    }

    // GET SELECTED PAYROLL ID
    private int getSelectedPayrollID() {

        int row = pv.payrollTable.getSelectedRow();

        if (row == -1) {

            JOptionPane.showMessageDialog(
                    pv, "Select a payroll row from the table first."
            );

            return -1;
        }

        return Integer.parseInt(
                pv.payrollTable.getValueAt(row, 0).toString()
        );
    }

    // FILL FIELDS FROM SELECTED ROW
    private void fillFieldsFromSelectedRow() {

        int row = pv.payrollTable.getSelectedRow();

        if (row == -1) {
            return;
        }

        pv.cmbEmployeeIDd.setSelectedItem(
                pv.payrollTable.getValueAt(row, 1).toString()
        );

        pv.jTextField2.setText(
                pv.payrollTable.getValueAt(row, 2).toString()
        );

        pv.jTextField3.setText(
                pv.payrollTable.getValueAt(row, 3).toString()
        );

        pv.jTextField4.setText(
                pv.payrollTable.getValueAt(row, 4).toString()
        );

        pv.jTextField5.setText(
                pv.payrollTable.getValueAt(row, 5).toString()
        );

        pv.jTextField6.setText(
                pv.payrollTable.getValueAt(row, 7).toString()
        );

        pv.jTextField7.setText(
                pv.payrollTable.getValueAt(row, 9).toString()
        );

        pv.jTextField8.setText(
                pv.payrollTable.getValueAt(row, 11).toString()
        );
    }

    // GET FORM DETAILS
    private PayrollDetails getFormDetails() {

        Object selected = pv.cmbEmployeeIDd.getSelectedItem();

        if (selected == null) {

            JOptionPane.showMessageDialog(
                    pv, "Please select an Employee ID."
            );

            return null;
        }

        try {

            String payDateText = pv.jTextField2.getText().trim();
            String payPeriod = pv.jTextField3.getText().trim();
            String dailyRateText = pv.jTextField4.getText().trim();
            String daysWorkedText = pv.jTextField5.getText().trim();
            String overtimeText = pv.jTextField6.getText().trim();
            String deductionsText = pv.jTextField7.getText().trim();
            String paymentStatus = pv.jTextField8.getText().trim();

            if (payDateText.isEmpty()
                    || payPeriod.isEmpty()
                    || dailyRateText.isEmpty()
                    || daysWorkedText.isEmpty()
                    || overtimeText.isEmpty()
                    || deductionsText.isEmpty()
                    || paymentStatus.isEmpty()) {

                JOptionPane.showMessageDialog(
                        pv, "Please fill in all payroll fields."
                );

                return null;
            }

            // CONVERT DATE
            LocalDate payDate = LocalDate.parse(payDateText);

            // CONVERT NUMBERS
            BigDecimal dailyRate = new BigDecimal(dailyRateText);
            int daysWorked = Integer.parseInt(daysWorkedText);
            BigDecimal overtime = new BigDecimal(overtimeText);
            BigDecimal deductions = new BigDecimal(deductionsText);

            // VALIDATE VALUES
            if (dailyRate.compareTo(BigDecimal.ZERO) < 0
                    || daysWorked < 0
                    || overtime.compareTo(BigDecimal.ZERO) < 0
                    || deductions.compareTo(BigDecimal.ZERO) < 0) {

                JOptionPane.showMessageDialog(
                        pv, "Payroll values cannot be negative."
                );

                return null;
            }

            // CALCULATE SALARY
            BigDecimal basicSalary = dailyRate
                    .multiply(BigDecimal.valueOf(daysWorked))
                    .setScale(2, RoundingMode.HALF_UP);

            BigDecimal grossSalary = basicSalary
                    .add(overtime)
                    .setScale(2, RoundingMode.HALF_UP);

            BigDecimal netSalary = grossSalary
                    .subtract(deductions)
                    .setScale(2, RoundingMode.HALF_UP);

            if (deductions.compareTo(grossSalary) > 0) {

                JOptionPane.showMessageDialog(
                        pv, "Deductions cannot exceed gross salary."
                );

                return null;
            }

            // CREATE PAYROLL OBJECT
            PayrollDetails p = new PayrollDetails();

            p.setEmployeeID(selected.toString());
            p.setPay_date(payDate);
            p.setPay_period(payPeriod);
            p.setDaily_rate(dailyRate);
            p.setDays_worked(daysWorked);
            p.setBasic_salary(basicSalary);
            p.setOvertime_pay(overtime);
            p.setGross_salary(grossSalary);
            p.setDeductions(deductions);
            p.setNet_salary(netSalary);
            p.setPayment_status(paymentStatus);

            return p;

        } catch (NumberFormatException ex) {

            JOptionPane.showMessageDialog(
                    pv, "Please enter valid numbers for payroll amounts "
                    + "and days worked."
            );

        } catch (java.time.format.DateTimeParseException ex) {

            JOptionPane.showMessageDialog(
                    pv, "Pay date must use YYYY-MM-DD format."
            );
        }

        return null;
    }

    // CLEAR FIELDS
    private void clearFields() {

        pv.jTextField2.setText("");
        pv.jTextField3.setText("");
        pv.jTextField4.setText("");
        pv.jTextField5.setText("");
        pv.jTextField6.setText("");
        pv.jTextField7.setText("");
        pv.jTextField8.setText("");

        pv.payrollTable.clearSelection();
    }

    // ERROR MESSAGE
    private void showError(SQLException ex) {

        JOptionPane.showMessageDialog(
                pv,
                "Database error: " + ex.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }

    // BUTTON EVENTS
    public class AllActions implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            Object source = e.getSource();

            // REFRESH
            if (source == pv.refreshBTN3) {

                loadEmployeeIDs();
                loadPayrollTable();
                clearFields();

                JOptionPane.showMessageDialog(
                        pv, "Employee IDs and payroll table refreshed!"
                );

                return;
            }

            // READ
            if (source == pv.readBTN3) {

                loadEmployeeIDs();
                loadPayrollTable();

                return;
            }

            // SAVE
            if (source == pv.saveBTN3) {

                PayrollDetails p = getFormDetails();

                if (p != null && DAO3.save(p)) {

                    loadPayrollTable();
                    clearFields();
                }

                return;
            }

            // UPDATE
            if (source == pv.updateBTN3) {

                int id = getSelectedPayrollID();

                if (id == -1) {
                    return;
                }

                PayrollDetails p = getFormDetails();

                if (p == null) {
                    return;
                }

                int choice = JOptionPane.showConfirmDialog(
                        pv,
                        "Update the selected payroll record?",
                        "Confirm Update",
                        JOptionPane.YES_NO_OPTION
                );

                if (choice == JOptionPane.YES_OPTION) {

                    if (DAO3.update(id, p)) {

                        loadPayrollTable();
                        clearFields();
                    }
                }

                return;
            }

            // DELETE
            if (source == pv.deleteBTN3) {

                int id = getSelectedPayrollID();

                if (id == -1) {
                    return;
                }

                int choice = JOptionPane.showConfirmDialog(
                        pv,
                        "Delete the selected payroll record?",
                        "Confirm Delete",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE
                );

                if (choice == JOptionPane.YES_OPTION) {

                    if (DAO3.delete(id)) {

                        loadPayrollTable();
                        clearFields();
                    }
                }
            }
        }
    }
}
