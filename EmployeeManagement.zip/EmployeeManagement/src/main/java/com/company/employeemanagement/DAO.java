package com.company.employeemanagement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class DAO {

    public static boolean save(Employee em) {

        String sql = "INSERT INTO employees "
                + "(employeeID, first_name, last_name, birthday, age, email, phone) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DB.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, em.getEmployeeID());
            stmt.setString(2, em.getFirst_name());
            stmt.setString(3, em.getLast_name());

            if (em.getBirthday() == null) {
                stmt.setDate(4, null);
            } else {
                stmt.setDate(4,
                        java.sql.Date.valueOf(em.getBirthday()));
            }

            stmt.setInt(5, em.getAge());
            stmt.setString(6, em.getEmail());
            stmt.setString(7, em.getPhone());

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Employee Added!");

            return true;

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                    null,
                    "Database Error: " + ex.getMessage()
            );

            return false;
        }
    }
}