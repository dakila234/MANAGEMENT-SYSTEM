
package com.company.employeemanagement;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

public class EmploymentDetailsController {

    EmploymentDetailsView edv;

    private DefaultTableModel tableModel;
    private boolean loadingEmployeeIDs = false;

    public EmploymentDetailsController(EmploymentDetailsView temp1) {

        edv = temp1;

        tableModel = new DefaultTableModel(
                new String[]{
                    "ID",
                    "Employee ID",
                    "Job Position",
                    "Salary",
                    "Employment Status",
                    "Hired Date"
                }, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        edv.employmentTable.setModel(tableModel);

        edv.employmentTable.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );

        edv.allListeners(new AllActions());

        loadEmployeeIDs();
        loadEmploymentTable();

        // COMBOBOX LISTENER
        edv.cmbEmployeeID.addActionListener(e -> {

            if (!loadingEmployeeIDs) {
                loadSelectedDetails();
            }
        });

        // TABLE SELECTION LISTENER
        edv.employmentTable.getSelectionModel()
                .addListSelectionListener(e -> {

                    if (!e.getValueIsAdjusting()) {

                        int row = edv.employmentTable.getSelectedRow();

                        if (row >= 0) {

                            String employeeID =
                                    tableModel.getValueAt(row, 1).toString();

                            edv.cmbEmployeeID.setSelectedItem(employeeID);
                        }
                    }
                });

        loadSelectedDetails();
    }

    // LOAD EMPLOYEE IDS
    private void loadEmployeeIDs() {

        ArrayList<String> employeeIDs = new ArrayList<>();

        String sql = "SELECT employeeID FROM employees "
                + "ORDER BY employeeID";

        // Retrieve IDs first and close ResultSet
        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                employeeIDs.add(rs.getString("employeeID"));
            }

        } catch (SQLException ex) {
            showError(ex);
            return;
        }

        // Update ComboBox after ResultSet is closed
        loadingEmployeeIDs = true;

        try {

            edv.cmbEmployeeID.removeAllItems();

            for (String employeeID : employeeIDs) {
                edv.cmbEmployeeID.addItem(employeeID);
            }

        } finally {
            loadingEmployeeIDs = false;
        }

        // Read selected employee after loading is finished
        loadSelectedDetails();
    }

    // LOAD EMPLOYMENT TABLE
    private void loadEmploymentTable() {

        tableModel.setRowCount(0);

        String sql = "SELECT id, employeeID, job_position, salary, "
                + "employment_status, hire_date "
                + "FROM employment_details "
                + "ORDER BY id";

        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                tableModel.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("employeeID"),
                    rs.getString("job_position"),
                    rs.getBigDecimal("salary"),
                    rs.getString("employment_status"),
                    rs.getDate("hire_date")
                });
            }

        } catch (SQLException ex) {
            showError(ex);
        }
    }

    // GET SELECTED EMPLOYEE ID
    private String getSelectedEmployeeID() {

        Object selected = edv.cmbEmployeeID.getSelectedItem();

        return selected == null ? null : selected.toString();
    }

    // READ SELECTED EMPLOYMENT DETAILS
    private void loadSelectedDetails() {

        String employeeID = getSelectedEmployeeID();

        if (employeeID == null) {
            clearFields();
            return;
        }

        EmploymentDetails em = DAO2.read(employeeID);

        if (em == null) {
            clearFields();
            return;
        }

        edv.jTextField2.setText(em.getJob_position());

        edv.jTextField3.setText(
                em.getSalary() == null
                        ? ""
                        : em.getSalary().toString()
        );

        edv.jTextField4.setText(em.getEmployment_status());

        edv.jTextField5.setText(
                em.getHire_date() == null
                        ? ""
                        : em.getHire_date().toString()
        );
    }

    // CLEAR FIELDS
    private void clearFields() {

        edv.jTextField2.setText("");
        edv.jTextField3.setText("");
        edv.jTextField4.setText("");
        edv.jTextField5.setText("");
    }

    // GET FORM DETAILS
    private EmploymentDetails getFormDetails() {

        String employeeID = getSelectedEmployeeID();

        if (employeeID == null) {

            JOptionPane.showMessageDialog(
                    edv, "Please select an Employee ID."
            );

            return null;
        }

        String jobPosition = edv.jTextField2.getText().trim();
        String salaryText = edv.jTextField3.getText().trim();
        String employmentStatus = edv.jTextField4.getText().trim();
        String hireDateText = edv.jTextField5.getText().trim();

        if (jobPosition.isEmpty()
                || salaryText.isEmpty()
                || employmentStatus.isEmpty()
                || hireDateText.isEmpty()) {

            JOptionPane.showMessageDialog(
                    edv, "Please fill in all fields."
            );

            return null;
        }

        try {

            BigDecimal salary = new BigDecimal(salaryText);

            if (salary.compareTo(BigDecimal.ZERO) < 0) {

                JOptionPane.showMessageDialog(
                        edv, "Salary cannot be negative."
                );

                return null;
            }

            LocalDate hireDate = LocalDate.parse(hireDateText);

            EmploymentDetails em = new EmploymentDetails();

            em.setEmployeeID(employeeID);
            em.setJob_position(jobPosition);
            em.setSalary(salary);
            em.setEmployment_status(employmentStatus);
            em.setHire_date(hireDate);

            return em;

        } catch (NumberFormatException ex) {

            JOptionPane.showMessageDialog(
                    edv, "Salary must be a valid number."
            );

        } catch (java.time.format.DateTimeParseException ex) {

            JOptionPane.showMessageDialog(
                    edv, "Hire date must use YYYY-MM-DD format."
            );
        }

        return null;
    }

    // CLEAR FORM
    private void clearForm() {

        clearFields();
        edv.employmentTable.clearSelection();
    }

    // ERROR MESSAGE
    private void showError(SQLException ex) {

        JOptionPane.showMessageDialog(
                edv,
                "Database error: " + ex.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }

    // BUTTON EVENTS
    class AllActions implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            Object source = e.getSource();

            // REFRESH
            if (source == edv.refreshBTN2) {

                loadEmployeeIDs();
                loadEmploymentTable();

                JOptionPane.showMessageDialog(
                        edv, "Employee IDs and table refreshed!"
                );

                return;
            }

            // READ
            if (source == edv.readBTN2) {

                loadSelectedDetails();
                loadEmploymentTable();

                return;
            }

            // SAVE
            if (source == edv.saveBTN2) {

                EmploymentDetails em = getFormDetails();

                if (em != null && DAO2.save(em)) {

                    loadEmploymentTable();
                    loadSelectedDetails();
                }

                return;
            }

            // UPDATE
            if (source == edv.updateBTN2) {

                EmploymentDetails em = getFormDetails();

                if (em != null) {

                    int choice = JOptionPane.showConfirmDialog(
                            edv,
                            "Update employment details for "
                            + em.getEmployeeID() + "?",
                            "Confirm Update",
                            JOptionPane.YES_NO_OPTION
                    );

                    if (choice == JOptionPane.YES_OPTION) {

                        if (DAO2.update(em)) {

                            loadEmploymentTable();
                            loadSelectedDetails();
                        }
                    }
                }

                return;
            }

            // DELETE
            if (source == edv.deleteBTN2) {

                String employeeID = getSelectedEmployeeID();

                if (employeeID == null) {

                    JOptionPane.showMessageDialog(
                            edv, "Please select an Employee ID."
                    );

                    return;
                }

                int choice = JOptionPane.showConfirmDialog(
                        edv,
                        "Delete employment details for "
                        + employeeID + "?\n"
                        + "The employee record itself will not be deleted.",
                        "Confirm Delete",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE
                );

                if (choice == JOptionPane.YES_OPTION) {

                    if (DAO2.delete(employeeID)) {

                        clearForm();
                        loadEmploymentTable();
                    }
                }
            }
        }
    }
}
