package com.company.employeemanagement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Date;
import java.sql.Time;
import javax.swing.JOptionPane;

public class DAO4 {

    public static void save(AttendanceDetails attendance) {

        String sql = "INSERT INTO attendance "
                + "(employeeID, work_date, shift, login_time, logout_time, status) "
                + "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = DB.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, attendance.getEmployeeID());

            stmt.setDate(2, Date.valueOf(attendance.getWork_date()));

            stmt.setString(3, attendance.getShift());

            if (attendance.getLogin_time() == null) {
                stmt.setNull(4, java.sql.Types.TIME);
            } else {
                stmt.setTime(4, Time.valueOf(attendance.getLogin_time()));
            }

            if (attendance.getLogout_time() == null) {
                stmt.setNull(5, java.sql.Types.TIME);
            } else {
                stmt.setTime(5, Time.valueOf(attendance.getLogout_time()));
            }

            stmt.setString(6, attendance.getStatus());

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Attendance Added!");

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(
                    null,
                    "Failed to save attendance: " + ex.getMessage()
            );
        }
    }
}