

package com.company.employeemanagement;

public class EmployeeManagement {

    public static void main(String[] args) {

        java.awt.EventQueue.invokeLater(() -> {

            EmployeeView ev = new EmployeeView();
            EmploymentDetailsView edv = new EmploymentDetailsView();
            PayrollView pv = new PayrollView();
            AttendanceView av = new AttendanceView();

            new EmployeeController(ev);
            new EmploymentDetailsController(edv);
            new PayrollController(pv);
            new AttendanceController(av);

            DashboardView dashboard =
                    new DashboardView(ev, edv, pv, av);

            dashboard.setVisible(true);
        });
    }
}
