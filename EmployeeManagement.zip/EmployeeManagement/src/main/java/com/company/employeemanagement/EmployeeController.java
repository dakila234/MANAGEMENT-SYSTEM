
package com.company.employeemanagement;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class EmployeeController {

    EmployeeView ev;
    private DefaultTableModel tableModel;

    public EmployeeController(EmployeeView temp) {

        ev = temp;

        ev.allListeners(new AllActions());

        tableModel = new DefaultTableModel(
                new String[]{
                    "ID",
                    "Employee ID",
                    "First Name",
                    "Last Name",
                    "Birthday",
                    "Age",
                    "Email",
                    "Phone"
                }, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        ev.employeeTable.setModel(tableModel);

        loadEmployeeTable();
    }

    // LOAD EMPLOYEES
    private void loadEmployeeTable() {

        tableModel.setRowCount(0);

        String sql = "SELECT id, employeeID, first_name, last_name, "
                + "birthday, age, email, phone "
                + "FROM employees ORDER BY id";

        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                tableModel.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("employeeID"),
                    rs.getString("first_name"),
                    rs.getString("last_name"),
                    rs.getDate("birthday"),
                    rs.getInt("age"),
                    rs.getString("email"),
                    rs.getString("phone")
                });
            }

        } catch (SQLException ex) {
            showError(ex);
        }
    }

    // READ EMPLOYEE
    private void readEmployee() {

        String id = ev.jTextField1.getText().trim();

        if (id.isEmpty()) {
            JOptionPane.showMessageDialog(ev,
                    "Enter Employee ID first.");
            return;
        }

        String sql = "SELECT * FROM employees WHERE employeeID = ?";

        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, id);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    ev.jTextField2.setText(rs.getString("first_name"));
                    ev.jTextField3.setText(rs.getString("last_name"));

                    java.sql.Date birthday = rs.getDate("birthday");

                    ev.jTextField4.setText(
                            birthday == null ? "" : birthday.toString()
                    );

                    ev.jTextField5.setText(
                            String.valueOf(rs.getInt("age"))
                    );

                    ev.jTextField6.setText(rs.getString("email"));
                    ev.jTextField7.setText(rs.getString("phone"));

                    JOptionPane.showMessageDialog(ev,
                            "Employee found!");

                } else {
                    JOptionPane.showMessageDialog(ev,
                            "Employee not found.");
                }
            }

        } catch (SQLException ex) {
            showError(ex);
        }
    }

    // SAVE EMPLOYEE
    private void saveEmployee() {

        try {

            Employee em = new Employee();

            String id = ev.jTextField1.getText().trim();
            String firstName = ev.jTextField2.getText().trim();
            String lastName = ev.jTextField3.getText().trim();
            String birthdayText = ev.jTextField4.getText().trim();
            String ageText = ev.jTextField5.getText().trim();
            String email = ev.jTextField6.getText().trim();
            String phone = ev.jTextField7.getText().trim();

            if (id.isEmpty() || firstName.isEmpty()
                    || lastName.isEmpty() || ageText.isEmpty()) {

                JOptionPane.showMessageDialog(ev,
                        "Please fill in the required fields.");
                return;
            }

            em.setEmployeeID(id);
            em.setFirst_name(firstName);
            em.setLast_name(lastName);

            if (birthdayText.isEmpty()) {
                em.setBirthday(null);
            } else {
                em.setBirthday(LocalDate.parse(birthdayText));
            }

            em.setAge(Integer.parseInt(ageText));
            em.setEmail(email);
            em.setPhone(phone);

            if (DAO.save(em)) {
                loadEmployeeTable();
                clearFields();
            }

        } catch (NumberFormatException ex) {

            JOptionPane.showMessageDialog(ev,
                    "Age must be a valid number.");

        } catch (java.time.format.DateTimeParseException ex) {

            JOptionPane.showMessageDialog(ev,
                    "Birthday must use YYYY-MM-DD format.");
        }
    }

    // UPDATE EMPLOYEE
    private void updateEmployee() {

        String id = ev.jTextField1.getText().trim();

        if (id.isEmpty()) {
            JOptionPane.showMessageDialog(ev,
                    "Enter Employee ID first.");
            return;
        }

        try {

            String sql = "UPDATE employees SET "
                    + "first_name = ?, last_name = ?, birthday = ?, "
                    + "age = ?, email = ?, phone = ? "
                    + "WHERE employeeID = ?";

            try (Connection con = DB.getConnection();
                 PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setString(1, ev.jTextField2.getText().trim());
                ps.setString(2, ev.jTextField3.getText().trim());

                String birthday = ev.jTextField4.getText().trim();

                if (birthday.isEmpty()) {
                    ps.setDate(3, null);
                } else {
                    ps.setDate(3,
                            java.sql.Date.valueOf(
                                    LocalDate.parse(birthday)
                            ));
                }

                ps.setInt(4, Integer.parseInt(
                        ev.jTextField5.getText().trim()
                ));

                ps.setString(5, ev.jTextField6.getText().trim());
                ps.setString(6, ev.jTextField7.getText().trim());
                ps.setString(7, id);

                int result = ps.executeUpdate();

                if (result > 0) {

                    JOptionPane.showMessageDialog(ev,
                            "Employee updated!");

                    loadEmployeeTable();

                } else {
                    JOptionPane.showMessageDialog(ev,
                            "Employee ID not found.");
                }
            }

        } catch (NumberFormatException ex) {

            JOptionPane.showMessageDialog(ev,
                    "Age must be a valid number.");

        } catch (java.time.format.DateTimeParseException ex) {

            JOptionPane.showMessageDialog(ev,
                    "Birthday must use YYYY-MM-DD format.");

        } catch (SQLException ex) {
            showError(ex);
        }
    }

    // DELETE EMPLOYEE
    private void deleteEmployee() {

        String id = ev.jTextField1.getText().trim();

        if (id.isEmpty()) {
            JOptionPane.showMessageDialog(ev,
                    "Enter Employee ID first.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(
                ev,
                "Delete employee " + id + "?",
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION
        );

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        String sql = "DELETE FROM employees WHERE employeeID = ?";

        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, id);

            int result = ps.executeUpdate();

            if (result > 0) {

                JOptionPane.showMessageDialog(ev,
                        "Employee deleted!");

                clearFields();
                loadEmployeeTable();

            } else {
                JOptionPane.showMessageDialog(ev,
                        "Employee ID not found.");
            }

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(ev,
                    "Cannot delete employee. Check whether this employee "
                    + "has related employment, attendance, or payroll records.\n"
                    + ex.getMessage());
        }
    }

    // CLEAR FIELDS
    private void clearFields() {

        ev.jTextField1.setText("");
        ev.jTextField2.setText("");
        ev.jTextField3.setText("");
        ev.jTextField4.setText("");
        ev.jTextField5.setText("");
        ev.jTextField6.setText("");
        ev.jTextField7.setText("");
    }

    // ERROR MESSAGE
    private void showError(SQLException ex) {

        JOptionPane.showMessageDialog(
                ev,
                "Database error: " + ex.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }

    // BUTTON EVENTS
    class AllActions implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            Object source = e.getSource();

            if (source == ev.saveBTN) {
                saveEmployee();

            } else if (source == ev.readBTN) {
                readEmployee();

            } else if (source == ev.updateBTN) {
                updateEmployee();

            } else if (source == ev.deleteBTN) {
                deleteEmployee();
            }
        }
    }
}
